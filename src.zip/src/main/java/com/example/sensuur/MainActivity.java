package com.example.sensuur;

import static java.lang.Math.abs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor lSensor, aSensor;

    private ImageView background, man;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        background = (ImageView) findViewById(R.id.background);
        man = (ImageView) findViewById(R.id.man);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        lSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        aSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);

        sensorManager.registerListener(this, lSensor, SensorManager.SENSOR_DELAY_FASTEST);
        sensorManager.registerListener(this, aSensor, SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT){
            if(sensorEvent.values[0]>1500){
                background.setImageResource(R.drawable.table);
            } else {
                background.setImageResource(R.drawable.pocket);
            }
        } else {
            if(abs(sensorEvent.values[0]) > 0.4 || abs(sensorEvent.values[1]) > 9.9 || abs(sensorEvent.values[2]) > 0.4){
                man.setImageResource(R.drawable.moving);
            } else {
                man.setImageResource(R.drawable.still);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, lSensor, SensorManager.SENSOR_DELAY_FASTEST);
        sensorManager.registerListener(this, aSensor, SensorManager.SENSOR_DELAY_FASTEST);
    }
}